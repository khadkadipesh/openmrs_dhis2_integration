package org.openmrs.module.dhisconnector;

/**
 * Created by k-joseph on 04/07/2017.
 */
public class DHIS2APITest {

}
